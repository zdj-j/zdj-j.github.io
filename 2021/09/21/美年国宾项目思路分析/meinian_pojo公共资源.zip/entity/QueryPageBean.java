package org.zdj.entity;

import java.io.Serializable;

/**
 * @Author: Small-J
 * @Date: 2021-09-19
 * QueryPageBean: 封装查询条件
 */

public class QueryPageBean implements Serializable{
    /**
     * currentPage : 页码
     * pageSize : 每页记录数
     * queryString ： 查询条件
     */

    private Integer currentPage;
    private Integer pageSize;
    private String queryString;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getQueryString() {
        return queryString;
    }

    public void setQueryString(String queryString) {
        this.queryString = queryString;
    }

    @Override
    public String toString() {
        return "QueryPageBean{" +
                "currentPage=" + currentPage +
                ", pageSize=" + pageSize +
                ", queryString='" + queryString + '\'' +
                '}';
    }
}