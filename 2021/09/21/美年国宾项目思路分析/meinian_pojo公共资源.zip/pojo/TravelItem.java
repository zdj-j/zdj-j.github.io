package org.zdj.pojo;

import java.io.Serializable;


/**
 * @Author: Small-J
 * @Date: 2021/9/20
 * TravelItem : 自由行（单项旅游）
 */

public class TravelItem implements Serializable {
    /**
     * id : 主键
     * code : 自由行项目编号
     * name : 项目名称
     * sex : 适用性别
     * age : 年龄
     * price ： 价格
     * type ： 项目说明
     * attention : 注意事项
     */

    private Integer id;
    private String code;
    private String name;
    private String sex;
    private String age;
    private Float price;
    private String type;
    private String remark;
    private String attention;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAttention() {
        return attention;
    }

    public void setAttention(String attention) {
        this.attention = attention;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "TravelItem{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", age='" + age + '\'' +
                ", price=" + price +
                ", type='" + type + '\'' +
                ", remark='" + remark + '\'' +
                ", attention='" + attention + '\'' +
                '}';
    }
}
